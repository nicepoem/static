<?php

if (!defined('ABSPATH'))
    exit;

function zic_settings_page()
{
    // 1. 数据获取逻辑
    $post_types = get_post_types(['public' => true], 'objects');
    $enabled_types = get_option('zic_enabled_post_types');
    if (!$enabled_types || !is_array($enabled_types)) {
        $enabled_types = array('post', 'page');
    }
    $delete_featured = get_option('zic_delete_featured', '1');
    $enable_log = get_option('zic_enable_log', '1');
    $exclude_keywords = get_option('zic_exclude_keywords', '');

    // 2. 表单处理逻辑
    if (isset($_POST['zic_clear_log']) && check_admin_referer('zic_save_settings')) {
        $log_file = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($log_file)) {
            file_put_contents($log_file, '');
            echo '<div class="notice notice-success is-dismissible"><p>日志已清空。</p></div>';
        }
    }

    if (isset($_POST['zic_save_settings']) && check_admin_referer('zic_save_settings')) {
        $selected = isset($_POST['zic_post_types']) ? array_map('sanitize_text_field', $_POST['zic_post_types']) : [];
        update_option('zic_enabled_post_types', $selected);
        update_option('zic_delete_featured', isset($_POST['zic_delete_featured']) ? '1' : '0');
        update_option('zic_enable_log', isset($_POST['zic_enable_log']) ? '1' : '0');
        update_option('zic_exclude_keywords', sanitize_text_field($_POST['zic_exclude_keywords'] ?? ''));
        echo '<div class="notice notice-success is-dismissible"><p>设置已保存。</p></div>';

        $enabled_types = $selected;
        $delete_featured = isset($_POST['zic_delete_featured']) ? '1' : '0';
        $enable_log = isset($_POST['zic_enable_log']) ? '1' : '0';
        $exclude_keywords = sanitize_text_field($_POST['zic_exclude_keywords'] ?? '');
    }
?>

    <div class="art-pro-admin zic-wrap">
        <div class="zic-header">
            <div>
                <h1>智能媒体管理</h1>
                <p>扫描并清理未使用的媒体文件，释放服务器空间。</p>
            </div>
            <div>
                <a href="https://penx.cn" target="_blank" class="zic-btn zic-btn-secondary">
                    <span class="dashicons dashicons-admin-site-alt3"></span> 访问官网
                </a>
            </div>
        </div>

        <nav class="zic-nav">
            <a id="nav-settings" class="active" data-tab="settings">
                <span class="dashicons dashicons-admin-settings zic-nav-icon"></span> 设置
            </a>
            <a id="nav-scan" class="" data-tab="scan">
                <span class="dashicons dashicons-search zic-nav-icon"></span> 扫描与清理
            </a>
            <a id="nav-logs" class="" data-tab="logs">
                <span class="dashicons dashicons-text zic-nav-icon"></span> 运行日志
            </a>
        </nav>

        <div class="zic-tab-content">

            <div class="zic-tab-panel active" id="tab-settings">
                <form method="post">
                    <?php wp_nonce_field('zic_save_settings'); ?>

                    <div class="zic-card">
                        <div class="zic-card-title">
                            <span class="dashicons dashicons-controls-volumeon" style="color:var(--art-primary)"></span> 基础设置
                        </div>
                        <div class="zic-card-body">
                            <div class="zic-form-group">
                                <label class="zic-form-label">启用的文章类型</label>
                                <p class="description" style="margin-bottom: 15px;">选择需要检测引用的文章类型。未选中的类型中的图片引用将被忽略。</p>
                                <div class="zic-checkbox-grid">
                                    <?php foreach ($post_types as $type): ?>
                                        <label class="zic-checkbox-label">
                                            <input type="checkbox" name="zic_post_types[]"
                                                value="<?php echo esc_attr($type->name); ?>" <?php checked(in_array($type->name, $enabled_types)); ?> />
                                            <span><?php echo esc_html($type->labels->singular_name); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="zic-card">
                        <div class="zic-card-title">
                            <span class="dashicons dashicons-trash" style="color:var(--art-danger)"></span> 清理策略
                        </div>
                        <div class="zic-card-body">
                            <div class="zic-form-group">
                                <label class="zic-checkbox-label" style="display:inline-flex; width: auto;">
                                    <input type="checkbox" name="zic_delete_featured" value="1" <?php checked($delete_featured, '1'); ?> />
                                    <span>删除文章时一并删除特色图片</span>
                                </label>
                            </div>

                            <div class="zic-form-group">
                                <label class="zic-form-label" for="zic_exclude_keywords">排除关键字</label>
                                <input type="text" name="zic_exclude_keywords" id="zic_exclude_keywords"
                                    value="<?php echo esc_attr($exclude_keywords); ?>" class="zic-input-text"
                                    placeholder="例如：logo.png, banner" />
                                <p class="description" style="margin-top: 8px;">包含这些关键字的图片 URL 将永远不会被扫描或删除。</p>
                            </div>
                        </div>
                    </div>

                    <div class="zic-card">
                        <div class="zic-card-title">
                            <span class="dashicons dashicons-admin-tools" style="color:var(--art-warning)"></span> 调试选项
                        </div>
                        <div class="zic-card-body">
                            <label class="zic-checkbox-label" style="display:inline-flex; width: auto;">
                                <input type="checkbox" name="zic_enable_log" value="1" <?php checked($enable_log, '1'); ?> />
                                <span>启用调试日志 (wp-content/debug.log)</span>
                            </label>
                        </div>
                    </div>

                    <div style="margin-top: 8px;">
                        <button type="submit" name="zic_save_settings" class="zic-btn zic-btn-primary zic-btn-lg">
                            <span class="dashicons dashicons-saved"></span> 保存设置
                        </button>
                    </div>
                </form>
            </div>

            <div class="zic-tab-panel" id="tab-scan">
                <div class="zic-card">
                    <div class="zic-card-title">
                        <span class="dashicons dashicons-filter" style="color:var(--art-primary)"></span> 扫描控制
                    </div>
                    <div class="zic-card-body">
                        <div class="zic-filter-grid">
                            <div class="zic-filter-box">
                                <h4><span class="dashicons dashicons-flag"></span> 扫描模式</h4>
                                <div style="display: flex; gap: 30px;">
                                    <label style="display:block; cursor: pointer;">
                                        <input type="checkbox" id="zic-show-unused" checked />
                                        <strong>扫描未使用的文件</strong>
                                    </label>
                                    <label style="display:block; color: #64748b; cursor: pointer;">
                                        <input type="checkbox" id="zic-show-referenced" />
                                        <strong>显示有引用的文件</strong>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="zic-action-bar">
                            <button type="button" id="zic-scan-btn" class="zic-btn zic-btn-primary zic-btn-lg">
                                <span class="dashicons dashicons-search"></span> 开始全量扫描
                            </button>
                            <span id="zic-scan-status" style="font-weight: 500; color: var(--art-gray-600); margin-left: 10px;">准备就绪，点击左侧按钮开始...</span>
                        </div>
                    </div>
                </div>

                <div id="zic-scan-results" style="display: none;">

                    <div id="zic-scan-summary-cards" class="zic-stats-row"></div>
                    <div id="zic-scan-summary" style="display:none;"></div>

                    <div class="zic-card" style="padding:0; overflow:visible; border:none; box-shadow:none; background:transparent;">
                        <div class="zic-scan-toolbar">
                            <label style="font-weight: 600; font-size: 14px; display:flex; align-items:center; color:var(--art-gray-800);">
                                <input type="checkbox" id="zic-select-all" style="margin-right:8px;" /> 全选
                            </label>
                            <button type="button" id="zic-delete-selected" class="zic-btn zic-btn-danger"
                                style="display: none;">
                                <span class="dashicons dashicons-trash"></span> 批量删除
                            </button>
                        </div>

                        <div id="zic-image-list" class="zic-table-container"
                            style="border-radius: 0 0 12px 12px; margin-top: 0;">
                            <div id="zic-images-table"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="zic-tab-panel" id="tab-logs">
                <div class="zic-card">
                    <div class="zic-card-title">
                        <span class="dashicons dashicons-list-view" style="color:var(--art-gray-600)"></span> 系统日志
                    </div>
                    <div class="zic-card-body">
                        <p class="description" style="margin-bottom: 20px;">查看插件的运行日志，帮助排查问题。日志文件位于
                            <code>wp-content/debug.log</code>
                        </p>

                        <div class="zic-log-toolbar">
                            <button type="button" id="zicCopyLogBtn" class="zic-btn zic-btn-secondary zic-btn-sm">
                                <span class="dashicons dashicons-admin-page"></span> 复制日志
                            </button>
                            <button type="button" id="zicLogScrollBottom" class="zic-btn zic-btn-secondary zic-btn-sm">
                                <span class="dashicons dashicons-arrow-down-alt"></span> 滚到底部
                            </button>
                            <form method="post" style="display:inline-block; margin:0;">
                                <?php wp_nonce_field('zic_save_settings'); ?>
                                <button type="submit" name="zic_clear_log" class="zic-btn zic-btn-secondary zic-btn-sm zic-btn-log-clear"
                                    onclick="return confirm('确定要清空日志吗？');">
                                    <span class="dashicons dashicons-trash"></span> 清空日志
                                </button>
                            </form>
                            <label class="zic-log-filter-zic">
                                <input type="checkbox" id="zicLogZicOnly" checked />
                                <span>仅显示 ZIC</span>
                            </label>
                            <div class="zic-log-search-wrap">
                                <span class="dashicons dashicons-search"></span>
                                <input type="search" id="zicLogSearch" class="zic-log-search" placeholder="搜索日志内容..." autocomplete="off" />
                            </div>
                        </div>

                        <?php
                        $zic_log_raw = function_exists('zic_get_log_content') ? zic_get_log_content(2000) : '日志功能未启用或主插件未更新。';
                        $zic_log_stats = function_exists('zic_get_log_stats') ? zic_get_log_stats($zic_log_raw) : array('total' => 0, 'zic' => 0);
                        ?>

                        <div class="zic-log-container">
                            <div class="zic-log-header">
                                <div class="zic-log-header-left">
                                    <span class="zic-log-dot zic-log-dot-red"></span>
                                    <span class="zic-log-dot zic-log-dot-yellow"></span>
                                    <span class="zic-log-dot zic-log-dot-green"></span>
                                    <span class="zic-log-title">wp-content/debug.log</span>
                                </div>
                                <div class="zic-log-header-right">
                                    <span class="zic-log-stat" id="zicLogStatTotal"><?php echo (int) $zic_log_stats['total']; ?> 行</span>
                                    <span class="zic-log-stat zic-log-stat-zic" id="zicLogStatZic">ZIC <?php echo (int) $zic_log_stats['zic']; ?></span>
                                    <span class="zic-log-stat zic-log-stat-visible" id="zicLogStatVisible">显示 <?php echo (int) $zic_log_stats['total']; ?></span>
                                    <span class="zic-log-badge">只读</span>
                                </div>
                            </div>
                            <div class="zic-log-body" id="zicLogScroll">
                                <div id="zicLogContent" class="zic-log-lines"><?php
                                                                                if (function_exists('zic_format_log_html')) {
                                                                                    echo zic_format_log_html($zic_log_raw);
                                                                                } else {
                                                                                    echo '<div class="zic-log-empty"><p>日志功能未启用或主插件未更新。</p></div>';
                                                                                }
                                                                                ?></div>
                            </div>
                            <textarea id="zicLogRaw" class="zic-log-raw" readonly aria-hidden="true"><?php echo esc_textarea($zic_log_raw); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="zic-modal-overlay" id="zicSingleDeleteModal" style="display: none;">
        <div class="zic-modal">
            <div class="zic-modal-header">
                <h3 class="zic-modal-title">删除确认</h3>
                <button type="button" class="zic-modal-close" onclick="zicCloseModal('zicSingleDeleteModal')" aria-label="Close">&times;</button>
            </div>
            <div class="zic-modal-body">
                <p style="font-size: 15px; margin-top:0; color:var(--art-gray-700);">确定要删除该文件吗？</p>
                <div class="zic-delete-info" style="padding:16px; margin: 16px 0; font-size: 14px;">
                    <strong>注意：</strong>删除操作不可逆，请确认文件确实不再需要。
                </div>
                <div id="zic-single-delete-details" style="font-weight: 600; margin-top: 10px; color: var(--art-gray-800);"></div>
            </div>
            <div class="zic-modal-footer">
                <button type="button" class="zic-btn zic-btn-secondary" onclick="zicCloseModal('zicSingleDeleteModal')">取消</button>
                <button type="button" class="zic-btn zic-btn-danger" id="zic-confirm-single-delete" style="margin-left: 12px;">确认删除</button>
            </div>
        </div>
    </div>

    <div class="zic-modal-overlay" id="zicBatchDeleteModal" style="display: none;">
        <div class="zic-modal">
            <div class="zic-modal-header">
                <h3 class="zic-modal-title">批量删除</h3>
                <button type="button" class="zic-modal-close" onclick="zicCloseModal('zicBatchDeleteModal')" aria-label="Close">&times;</button>
            </div>
            <div class="zic-modal-body">
                <p style="font-size: 15px; margin-top:0; color:var(--art-gray-700);">确定要删除选中的图片吗？</p>
                <div class="zic-delete-info" style="padding:16px; margin: 16px 0; font-size: 14px;">
                    <strong>警告：</strong>这些文件将被永久删除且无法恢复。
                </div>
                <div id="zic-batch-delete-details" style="font-weight: 600; color: var(--art-gray-800);"></div>
            </div>
            <div class="zic-modal-footer">
                <button type="button" class="zic-btn zic-btn-secondary" onclick="zicCloseModal('zicBatchDeleteModal')">取消</button>
                <button type="button" class="zic-btn zic-btn-danger" id="zic-confirm-batch-delete" style="margin-left: 12px;">确认删除</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tab 切换逻辑
            const tabButtons = document.querySelectorAll('.zic-nav a');
            const tabPanels = document.querySelectorAll('.zic-tab-panel');

            // 读取保存的标签页状态
            const savedTab = localStorage.getItem('zic_active_tab');
            if (savedTab) {
                const targetBtn = document.querySelector(`.zic-nav a[data-tab="${savedTab}"]`);
                if (targetBtn) switchTab(targetBtn);
            }

            // 绑定点击事件
            tabButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    switchTab(this);
                    localStorage.setItem('zic_active_tab', this.getAttribute('data-tab'));
                });
            });

            function switchTab(clickedBtn) {
                const targetId = clickedBtn.getAttribute('data-tab');
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabPanels.forEach(panel => panel.classList.remove('active'));
                clickedBtn.classList.add('active');
                document.getElementById('tab-' + targetId).classList.add('active');
            }
        });

        function zicShowModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        function zicCloseModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                var modals = document.querySelectorAll('.zic-modal-overlay');
                modals.forEach(function(modal) {
                    if (modal.style.display === 'block') {
                        modal.style.display = 'none';
                        document.body.style.overflow = 'auto';
                    }
                });
            }
        });
        document.getElementById('zicCopyLogBtn').onclick = function() {
            var log = document.getElementById('zicLogRaw').value;
            navigator.clipboard.writeText(log).then(function() {
                var btn = document.getElementById('zicCopyLogBtn');
                var originalHtml = btn.innerHTML;
                btn.innerHTML = '<span class="dashicons dashicons-yes"></span> 已复制';
                setTimeout(function() {
                    btn.innerHTML = originalHtml;
                }, 1500);
            });
        };

        (function initLogPanel() {
            var searchInput = document.getElementById('zicLogSearch');
            var zicOnlyInput = document.getElementById('zicLogZicOnly');
            var scrollBox = document.getElementById('zicLogScroll');
            var statVisible = document.getElementById('zicLogStatVisible');
            var lines = document.querySelectorAll('#zicLogContent .zic-log-line');

            function applyLogFilters() {
                var keyword = (searchInput && searchInput.value || '').trim().toLowerCase();
                var zicOnly = zicOnlyInput ? zicOnlyInput.checked : false;
                var visible = 0;

                lines.forEach(function(line) {
                    var text = line.textContent.toLowerCase();
                    var show = true;
                    if (zicOnly && line.getAttribute('data-zic-only') !== '1') {
                        show = false;
                    }
                    if (show && keyword && text.indexOf(keyword) === -1) {
                        show = false;
                    }
                    line.classList.toggle('is-hidden', !show);
                    if (show) {
                        visible++;
                    }
                });

                if (statVisible) {
                    statVisible.textContent = '显示 ' + visible;
                }
            }

            if (searchInput) {
                searchInput.addEventListener('input', applyLogFilters);
            }
            if (zicOnlyInput) {
                zicOnlyInput.addEventListener('change', applyLogFilters);
            }

            var scrollBtn = document.getElementById('zicLogScrollBottom');
            if (scrollBtn && scrollBox) {
                scrollBtn.addEventListener('click', function() {
                    scrollBox.scrollTop = scrollBox.scrollHeight;
                });
            }

            applyLogFilters();

            if (scrollBox) {
                scrollBox.scrollTop = scrollBox.scrollHeight;
            }
        })();

        // jQuery AJAX 逻辑
        jQuery(document).ready(function($) {
            var scanNonce = '<?php echo wp_create_nonce('zic_scan_nonce'); ?>';
            var deleteNonce = '<?php echo wp_create_nonce('zic_delete_nonce'); ?>';

            // 扫描按钮
            $('#zic-scan-btn').on('click', function() {
                var $btn = $(this);
                var $status = $('#zic-scan-status');

                var filters = {
                    show_unused_images: $('#zic-show-unused').is(':checked'),
                    show_ghost_images: false,
                    show_referenced_images: $('#zic-show-referenced').is(':checked'),
                    min_file_size: 0,
                    max_file_size: 0,
                    date_from: '',
                    date_to: '',
                    file_types: []
                };

                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> 全量扫描中...');
                $status.html('正在深度扫描媒体库，可能需要一些时间...');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'zic_scan_images',
                        nonce: scanNonce,
                        ...filters
                    },
                    success: function(response) {
                        if (response.success) {
                            renderNewResults(response.data);
                            $status.html('<span style="color:#0ca789; font-weight:600;">扫描完成</span>');
                        } else {
                            $status.html('<span style="color:var(--art-danger); font-weight:600;">扫描失败: ' + (response.data || '未知错误') + '</span>');
                        }
                    },
                    error: function() {
                        $status.html('<span style="color:var(--art-danger)">网络错误</span>');
                    },
                    complete: function() {
                        $btn.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> 重新扫描');
                    }
                });
            });

            // 渲染结果
            function renderNewResults(data) {
                var $results = $('#zic-scan-results');
                var $cards = $('#zic-scan-summary-cards');
                var $table = $('#zic-images-table');

                var totalSize = 0,
                    unusedCount = 0,
                    referencedCount = 0;
                data.unused_images.forEach(function(img) {
                    if (img.type === 'unused') {
                        unusedCount++;
                        if (img.file_exists) totalSize += img.file_size;
                    } else if (img.type === 'referenced') referencedCount++;
                });

                var cardsHtml = `
                    <div class="zic-stat-card">
                        <span class="zic-stat-value">${data.total_attachments}</span>
                        <span class="zic-stat-label">总文件数</span>
                    </div>
                    <div class="zic-stat-card highlight">
                        <span class="zic-stat-value">${unusedCount}</span>
                        <span class="zic-stat-label">未使用文件</span>
                    </div>
                    <div class="zic-stat-card highlight">
                        <span class="zic-stat-value">${formatFileSize(totalSize)}</span>
                        <span class="zic-stat-label">可释放空间</span>
                    </div>
                    <div class="zic-stat-card">
                        <span class="zic-stat-value">${referencedCount}</span>
                        <span class="zic-stat-label">有引用</span>
                    </div>
                `;
                $cards.html(cardsHtml);

                if (data.unused_images.length > 0) {
                    var tableHtml = '<table class="zic-table">' +
                        '<thead><tr>' +
                        '<th style="width: 30px;"></th>' +
                        '<th style="width: 50px;">ID</th>' +
                        '<th style="width: 60px;">预览</th>' +
                        '<th>标题</th>' +
                        '<th style="width: 80px;">类型</th>' +
                        '<th style="width: 80px;">状态</th>' +
                        '<th style="width: 80px;">大小</th>' +
                        '<th style="width: 100px;">上传日期</th>' +
                        '<th style="width: 80px;">操作</th>' +
                        '</tr></thead><tbody>';

                    data.unused_images.forEach(function(img) {
                        var badge = '';
                        if (img.type === 'ghost') badge = '<span class="zic-badge zic-badge-ghost">文件丢失</span>';
                        else if (img.type === 'unused') badge = '<span class="zic-badge zic-badge-unused">未使用</span>';
                        else if (img.type === 'referenced') badge = '<span class="zic-badge zic-badge-referenced">已引用</span>';

                        var preview = '';
                        if (img.url.match(/\.(jpg|jpeg|png|gif|webp)$/i)) {
                            preview = `<a href="${img.url}" target="_blank"><img src="${img.url}" style="width:42px; height:42px; object-fit:cover; border-radius:8px; border:1px solid var(--default-border);"></a>`;
                        } else {
                            preview = `<div style="width:42px; height:42px; background:var(--art-gray-200); border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:10px; color:var(--art-gray-600); font-weight:700;">${img.file_extension}</div>`;
                        }

                        // 生成引用链接
                        var refInfo = '';
                        if (img.references && img.references.length > 0) {
                            var refLinks = [];
                            img.references.forEach(function(ref) {
                                var linkUrl = '#';
                                if (ref.type === 'user') {
                                    linkUrl = 'user-edit.php?user_id=' + (ref.user_id || ref.id.replace('user-', ''));
                                } else {
                                    linkUrl = 'post.php?post=' + ref.id + '&action=edit';
                                }
                                refLinks.push(`<a href="${linkUrl}" target="_blank" style="color:var(--art-primary); text-decoration:none;">${ref.title}</a>`);
                            });
                            refInfo = `<div style="font-size:11px; color:var(--art-gray-600); margin-top:4px; line-height:1.5;">引用: ${refLinks.join('，')}</div>`;
                        }

                        var displayTitle = img.title || '无标题';

                        var deleteBtn = (img.type === 'unused' || img.type === 'ghost') ?
                            `<button type="button" class="zic-btn zic-btn-sm zic-btn-ghost-danger zic-delete-single" data-id="${img.id}">删除</button>` : '';

                        var checkbox = (img.type === 'referenced') ? '' : `<input type="checkbox" class="zic-image-checkbox" value="${img.id}" style="transform:scale(1.1);">`;

                        tableHtml += `<tr data-id="${img.id}">
                            <td>${checkbox}</td>
                            <td style="color:var(--art-gray-600); font-family: -apple-system, system-ui, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, sans-serif, BlinkMacSystemFont, Helvetica Neue, PingFang SC, Hiragino Sans GB, Microsoft YaHei, Arial !important; font-weight:600;">${img.id}</td>
                            <td>${preview}</td>
                            <td>
                                <div style="font-weight:600; color:var(--art-gray-800);">${displayTitle}</div>
                                ${refInfo}
                            </td>
                            <td>
                                <span style="background:var(--art-gray-200); padding:3px 8px; border-radius:6px; font-size:11px; font-weight:600; color:var(--art-gray-600);">${img.file_extension.toUpperCase()}</span>
                            </td>
                            <td>${badge}</td>
                            <td style="font-size:12px; color:#475569;">${formatFileSize(img.file_size)}</td>
                            <td style="font-size:12px; color:#64748b;">${img.upload_date.split(' ')[0]}</td>
                            <td>${deleteBtn}</td>
                        </tr>`;
                    });
                    tableHtml += '</tbody></table>';
                    $table.html(tableHtml);
                    $('#zic-delete-selected').show();
                } else {
                    $table.html('<div style="padding:60px; text-align:center; color:var(--art-gray-600);"><span class="dashicons dashicons-yes" style="font-size:40px; width:40px; height:40px; color:var(--art-success); margin-bottom:10px;"></span><br>太棒了！没有发现未使用的文件。</div>');
                    $('#zic-delete-selected').hide();
                }
                $results.fadeIn();
                bindTableEvents();
            }

            function formatFileSize(bytes) {
                if (bytes === 0) return '0 B';
                var k = 1024,
                    sizes = ['B', 'KB', 'MB', 'GB'],
                    i = Math.floor(Math.log(bytes) / Math.log(k));
                return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
            }

            function bindTableEvents() {
                $('#zic-select-all').off('change').on('change', function() {
                    $('.zic-image-checkbox').prop('checked', $(this).is(':checked'));
                    updateDeleteButton();
                });
                $(document).on('change', '.zic-image-checkbox', function() {
                    updateDeleteButton();
                    var total = $('.zic-image-checkbox').length;
                    var checked = $('.zic-image-checkbox:checked').length;
                    $('#zic-select-all').prop('checked', total > 0 && total === checked);
                });
                $(document).on('click', '.zic-delete-single', function() {
                    var id = $(this).data('id');
                    var $row = $(this).closest('tr');
                    var title = $row.find('td:eq(3) div:first').text();

                    $('#zic-single-delete-details').html(`<strong>${title}</strong> (ID: ${id})`);
                    $('#zic-confirm-single-delete').off('click').on('click', function() {
                        zicCloseModal('zicSingleDeleteModal');
                        deleteImages([id]);
                    });
                    zicShowModal('zicSingleDeleteModal');
                });

                $('#zic-delete-selected').off('click').on('click', function() {
                    var selectedIds = [];
                    $('.zic-image-checkbox:checked').each(function() {
                        selectedIds.push($(this).val());
                    });
                    if (selectedIds.length === 0) return;

                    $('#zic-batch-delete-details').html(`共选中 <strong>${selectedIds.length}</strong> 个文件`);
                    $('#zic-confirm-batch-delete').off('click').on('click', function() {
                        zicCloseModal('zicBatchDeleteModal');
                        deleteImages(selectedIds);
                    });
                    zicShowModal('zicBatchDeleteModal');
                });
            }

            function updateDeleteButton() {
                var c = $('.zic-image-checkbox:checked').length;
                var $btn = $('#zic-delete-selected');
                if (c > 0) {
                    $btn.show().html(`<span class="dashicons dashicons-trash"></span> 批量删除 (${c})`);
                } else {
                    $btn.hide();
                }
            }

            function deleteImages(ids) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'zic_delete_images',
                        nonce: deleteNonce,
                        image_ids: ids
                    },
                    success: function(res) {
                        if (res.success) {
                            ids.forEach(id => $('tr[data-id="' + id + '"]').fadeOut());
                        } else {
                            alert('删除失败');
                        }
                    }
                });
            }
        });
    </script>
<?php
}
